//
//  BlueViewController.swift
//  View Switcher
//
//  Created by Guneet Singh on 2017-06-22.
//  Copyright © 2017 Guneet Singh. All rights reserved.
//

import UIKit

class BlueViewController: UIViewController {
    
    
    @IBAction func tap(_ sender: UITapGestureRecognizer) {
        blueTextLabel.resignFirstResponder()
    }
    @IBOutlet weak var blueTextLabel: UITextField!
    
    @IBOutlet weak var blueLabel: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}

