//
//  YellowViewController.swift
//  View Switcher
//
//  Created by Guneet Singh on 2017-06-22.
//  Copyright © 2017 Guneet Singh. All rights reserved.
//

import UIKit

class YellowViewController: UIViewController {

    
    @IBAction func tap(_ sender: UITapGestureRecognizer) {
        yellowTextLabel.resignFirstResponder()
    }
    
    
    @IBOutlet weak var yellowTextLabel: UITextField!
    @IBOutlet weak var yellowLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}
