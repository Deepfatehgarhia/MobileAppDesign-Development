//
//  SwitchingViewController.swift
//  View Switcher
//
//  Created by Guneet Singh on 2017-06-22.
//  Copyright © 2017 Guneet Singh. All rights reserved.
//

import UIKit

class SwitchingViewController: UIViewController {

     var blueViewController: BlueViewController!
     var yellowViewController: YellowViewController!
    
    var message1:[String] = []
    var message2 = [String]()
    var counter: Int = 0
    var counter1: Int = 0
    
    @IBAction func tap(_ sender: UITapGestureRecognizer) {
        
        
        yellowViewController.yellowTextLabel.resignFirstResponder()
        
        blueViewController.blueTextLabel.resignFirstResponder()
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        blueViewController =
            storyboard?.instantiateViewController(withIdentifier: "Blue")
            as! BlueViewController
        blueViewController.view.frame = view.frame
        switchViewController(from: nil, to: blueViewController)  // helper method
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
        if blueViewController != nil
            && blueViewController!.view.superview == nil {
            blueViewController = nil
        }
        if yellowViewController != nil
            && yellowViewController!.view.superview == nil {
            yellowViewController = nil
        }
    }
    
    @IBAction func switchViews(sender: UIBarButtonItem) {
        
        // Create the new view controller, if required
        if yellowViewController?.view.superview == nil {
            if yellowViewController == nil {
                yellowViewController =
                    storyboard?.instantiateViewController(withIdentifier: "Yellow")
                    as! YellowViewController
        }
        } else if blueViewController?.view.superview == nil {
            if blueViewController == nil {
                blueViewController =
                    storyboard?.instantiateViewController(withIdentifier: "Blue")
                    as! BlueViewController
            } }
        UIView.beginAnimations("View Flip", context: nil)
        UIView.setAnimationDuration(0.4)
        UIView.setAnimationCurve(.easeInOut)
        // Switch view controllers
        
        if blueViewController != nil
            && blueViewController!.view.superview != nil {
            UIView.setAnimationTransition(.flipFromRight,
                                          for: view, cache: true)
                        yellowViewController.view.frame = view.frame
            
            message1.append(blueViewController.blueTextLabel.text!)
            yellowViewController.yellowLabel.text = ""
        
            for i in message1
            {   yellowViewController.yellowLabel.text?.append("\n")
                yellowViewController.yellowLabel.text?.append(i)
                counter += 1
                switchViewController(from: blueViewController, to: yellowViewController)
                if counter >= 5
                {
                    yellowViewController.yellowLabel.text?.append("\nConnection Terminated")
                    message1 = []
                   
                }
                        }
            counter = 0
            blueViewController.blueTextLabel.text = ""
        }
        else
        {
            UIView.setAnimationTransition(.flipFromLeft,
                                          for: view, cache: true)
            
            message2.append(yellowViewController.yellowTextLabel.text!)
            blueViewController.blueLabel.text = ""
            
            for i in message2
            {   blueViewController.blueLabel.text?.append("\n")
                blueViewController.blueLabel.text?.append(i)
                counter1 += 1
                switchViewController(from: yellowViewController, to: blueViewController)
                if counter1 >= 5
                {
                    blueViewController.blueLabel.text?.append("\nConnection Terminated")
                    message2 = []
                }
                
            }
            counter1 = 0
            yellowViewController.yellowTextLabel.text = ""
        }
        UIView.commitAnimations()
    }
    
    
    private func switchViewController(from fromVC:UIViewController?,
                                      to toVC:UIViewController?) {
        if fromVC != nil {
            fromVC!.willMove(toParentViewController: nil)
            fromVC!.view.removeFromSuperview()
            fromVC!.removeFromParentViewController()
        }
        if toVC != nil {
            self.addChildViewController(toVC!)
            self.view.insertSubview(toVC!.view, at: 0)
            toVC!.didMove(toParentViewController: self)
        }
    }
}
