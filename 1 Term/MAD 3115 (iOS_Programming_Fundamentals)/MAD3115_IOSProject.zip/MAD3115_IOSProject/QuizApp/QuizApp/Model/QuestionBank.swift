//
//  QuestionBank.swift
//  QuizApp
//
//  Created by Deepak Kumar on 2018-07-27.
//  Copyright © 2018 Deepak Kumar. All rights reserved.
//

import Foundation
import Foundation

class QuestionBank{
    var list = [Question]()
    
    init() {

        list.append(Question(questionText: "This road sign does not allow you to drive through intersection", choiceA: "Symbol4", choiceB: "Symbol18", choiceC: "Symbol1", choiceD: "Symbol13-1", answer: 4))
        
       list.append(Question(questionText: "This road sign does not allow people to park vehicles in area between signs.", choiceA: "Symbo2", choiceB: "Symbol8", choiceC: "Symbol4", choiceD: "Symbol9", answer: 1))
        
       list.append(Question(questionText: "This road sign shows the distance in kilometers to towns and cities on road.", choiceA: "Symbol7", choiceB: "Symbol14", choiceC: "Symbol13", choiceD: "Symbol8", answer: 1))
        
        list.append(Question(questionText: "This road sign indicates the sharp bend or turn in road ahead.", choiceA: "Symbol14", choiceB: "Symbol5", choiceC: "Symbol13-1", choiceD: "Symbol9", answer: 1))
        
        list.append(Question(questionText: "This road sign indicates the slight blend or curve in road ahead.", choiceA: "Symbol3" , choiceB: "Symbol18" , choiceC: "Symbol15" , choiceD: "Symbol17", answer: 4))
        
        list.append(Question(questionText: "This road sign allow only public vehicles such as buses or passenger vehicles carrying a specified number of passengers.", choiceA: "Symbol3" , choiceB: "Symbol20" , choiceC: "Symbol16" , choiceD: "Symbol15", answer: 1))
        
        list.append(Question(questionText: "This road sign demonstrates that traffic may travel in one direction only.", choiceA: "Symbol11", choiceB: "Symbol18", choiceC: "Symbol21", choiceD: "Symbol20", answer: 3))
        
        list.append(Question(questionText: "This road sign warns that you are coming to a school zone.", choiceA: "Symbol20", choiceB: "Symbol13", choiceC: "Symbol9", choiceD: "Symbol12", answer: 3))
        
        list.append(Question(questionText: "This road sign indicates that you must come to complete step.", choiceA: "Symbol8", choiceB: "Symbol18", choiceC: "Symbol22", choiceD: "Symbol13", answer: 1))
        
        list.append(Question(questionText: "This road sign indicates that you must not turn left at the intersection.", choiceA: "Symbol17", choiceB: "Symbol16", choiceC: "Symbol14", choiceD: "Symbol15", answer: 2))
        
    }
}
