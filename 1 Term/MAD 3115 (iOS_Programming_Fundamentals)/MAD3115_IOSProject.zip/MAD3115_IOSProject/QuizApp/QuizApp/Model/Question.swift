//
//  Question.swift
//  QuizApp
//
//  Created by Deepak Kumar on 2018-07-27.
//  Copyright © 2018 Deepak Kumar. All rights reserved.
//

import Foundation


import Foundation

class Question {
    let question: String
    let optA: String
    let optB: String
    let optC: String
    let optD: String
    let correctAnswer: Int
    
    init(questionText: String, choiceA: String, choiceB: String, choiceC: String, choiceD: String, answer: Int){
        
        question = questionText
        optA = choiceA
        optB = choiceB
        optC = choiceC
        optD = choiceD
        correctAnswer = answer
    }
}
