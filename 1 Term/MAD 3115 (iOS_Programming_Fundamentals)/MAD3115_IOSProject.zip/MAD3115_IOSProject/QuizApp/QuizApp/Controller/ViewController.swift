//
//  ViewController.swift
//  QuizApp
//
//  Created by Deepak Kumar on 2018-07-27.
//  Copyright © 2018 Deepak Kumar. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var questoinCounter: UILabel!
    @IBOutlet weak var scoreCounter: UILabel!
    @IBOutlet weak var questionLabel: UILabel!
    
    
    //Outlet for Buttons
    
    @IBOutlet weak var buttonA: UIButton!
    @IBOutlet weak var buttonB: UIButton!
    @IBOutlet weak var buttonC: UIButton!
    @IBOutlet weak var buttonD: UIButton!
    
    
    let allQuestions = QuestionBank()
    var questionCounter: Int = 1
    var score: Int  = 0
    var selectedAnswer: Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        updateQuestion()
        updateUI()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


    
    @IBAction func ansPressed(_ sender: UIButton) {
        
        
        if sender.tag == selectedAnswer {
            
            score += 1
            
        }
        
        questionCounter += 1
        updateQuestion()
    }
    
    func updateQuestion(){
        
        if (questionCounter <= 5){
            
            let  randomQuestionCounter = randomNumber(between: 0,and: 10)
            
            questionLabel.text = allQuestions.list[randomQuestionCounter].question
            buttonA.setImage(UIImage(named: (allQuestions.list[randomQuestionCounter].optA)), for: UIControlState.normal)
            buttonB.setImage(UIImage(named: (allQuestions.list[randomQuestionCounter].optB)), for: UIControlState.normal)
            buttonC.setImage(UIImage(named: (allQuestions.list[randomQuestionCounter].optC)), for: UIControlState.normal)
            buttonD.setImage(UIImage(named: (allQuestions.list[randomQuestionCounter].optD)), for: UIControlState.normal)
            selectedAnswer = allQuestions.list[randomQuestionCounter].correctAnswer
            
            updateUI()
            
            
        }else {
            
            if (score <= 2) {
                    let alert = UIAlertController(title: "Fail!", message: "Your Score is: \(score), less than 3. So please, restart the Quiz.", preferredStyle: .alert)
                    let restartAction = UIAlertAction(title: "Restart", style: .default, handler: {action in self.restartQuiz()})
                    alert.addAction(restartAction)
                    present(alert, animated: true, completion: nil)
            }
            else if( score == 3 )  {
                let alert = UIAlertController(title: "Good job!", message: "Your Score is : \(score). Do you want to start over?", preferredStyle: .alert)
                let restartAction = UIAlertAction(title: "Restart", style: .default, handler: {action in self.restartQuiz()})
                alert.addAction(restartAction)
                present(alert, animated: true, completion: nil)
            }
            
            else if( score == 4 )  {
                let alert = UIAlertController(title: "Excellent work!", message: "Your Score is : \(score). Do you want to start over?", preferredStyle: .alert)
                let restartAction = UIAlertAction(title: "Restart", style: .default, handler: {action in self.restartQuiz()})
                alert.addAction(restartAction)
                present(alert, animated: true, completion: nil)
            }
            else if( score == 5 )  {
                let alert = UIAlertController(title: "You are a genius!", message: "Your Score is : \(score). Do you want to start over?", preferredStyle: .alert)
                let restartAction = UIAlertAction(title: "Restart", style: .default, handler: {action in self.restartQuiz()})
                alert.addAction(restartAction)
                present(alert, animated: true, completion: nil)
            }
            
            
        }
        updateUI()
        
    }
    
    func updateUI(){
        scoreCounter.text = "Score: \(score)"
        questoinCounter.text = "\(questionCounter )/\(allQuestions.list.count - 5)"
     
        
    }
    
    func restartQuiz(){
        score = 0
        questionCounter = 0
        updateQuestion()
        
    }
    
    func randomNumber(between lower: Int, and upper: Int) -> Int {
        return Int(arc4random_uniform(UInt32(upper - lower))) + lower
    }
    
    func generateRandomUniqueNumbers1(forLowerBound lower: Int, andUpperBound upper:Int, andNumNumbers iterations: Int) -> [Int] {
        guard iterations <= (upper - lower) else { return [] }
        var numbers: [Int] = []
        (0..<iterations).forEach { _ in
            var nextNumber: Int
            repeat {
                nextNumber = randomNumber(between: lower, and: upper)
            } while numbers.contains(nextNumber)
            numbers.append(nextNumber)
        }
        return numbers
    }
    

    
    
}

