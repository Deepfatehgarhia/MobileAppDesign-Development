//
//  main.swift
//  tes2
//
//  
//

import Foundation

 var noofemp=""

print(" How many Employyess Detail  you want to enter;")
noofemp = readLine()!

    
    for _ in 1...Int(noofemp)!
    {
        let employees = Employee()
        employees.employee_id()
        employees.empFname()
        employees.emplname()
        employees.empDescription()
        
        
        
         noofemp += StockHolding(purchaseSharePrice: purchaseSharePrice!, currentSharePrice: currentSharePrice!, numberOfShares: noShares!, companyName: companyname)
        
        stocks += [stockholding]
        
    }



