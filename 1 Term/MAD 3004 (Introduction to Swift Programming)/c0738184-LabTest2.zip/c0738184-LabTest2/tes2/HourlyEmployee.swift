//
//  HourlyEmployee.swift
//  tes2
//
//  Created by Deepak Kumar on 2018-07-03.
//  Copyright © 2018 Gurpreet Verma. All rights reserved.
//

import Foundation
class HourlyEmployee: Employee, Taxable {
    
    
    
    var hourlyRate = ""
    
    var hoursWorked = ""
    var hourlySalary = 0
    
    var hourlydesc = "hourly"

    
    func employee_hoursWorked()
        
    {
        print("enter the employees Hours ")
        
        hourlyRate = readLine()!
        
        print("enter the employees yearly salry")
        
        hourlyRate = readLine()!
     
        
        
    }
    
    
    func employee_hourlysalary()
        
    {
       
      return  hourlySalary = Int(hourlyRate) * Int(hourlyRate)
        
    }
    
    
    override func outputempDescription()
    {
        
        
        print (hourlydesc)
    }
    
    
    
    
    
}
