//
//  Taxable.swift
//  tes2
//
//  Created by Deepak Kumar on 2018-07-03.
//  Copyright © 2018 Gurpreet Verma. All rights reserved.
//

import Foundation
protocol Taxable
{
    func income() -> Double 
}
