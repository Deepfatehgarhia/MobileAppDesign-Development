//
//  Employee.swift
//  tes2
//
//
//

import Cocoa

class SalariedEmployee: Employee, Taxable {
    
    
    
    var yearlySalary = ""
    
    var salarieddesc = "Salaried"
    
    func employee_yearlySalary()
        
    {
        print("enter the employees yearly salry")
        
        yearlySalary = readLine()!
    }
    
   
   override func outputempDescription()
    {
        
        
        print (salarieddesc)
    }
    
    
    
    
    
}
