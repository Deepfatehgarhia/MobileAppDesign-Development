//
//  BasePlusCommissionEmployee.swift].swift
//  tes2
//
//  Created by Deepak Kumar on 2018-07-03.
//  Copyright © 2018 Gurpreet Verma. All rights reserved.
//

import Foundation
class BasePlusCommissionEmployee: Employee, Taxable {
    
    
    
    var weeklySalary = ""
    var weeklySales = ""
    var commissionRate = ""
    
    var weeklydesc = "weekly"
    
    
    func employee_weekly()
        
    {
        print("enter the employees weeklySalary ")
        
        weeklySalary = readLine()!
        
        print("enter the employees weeklySales")
        
        weeklySales = readLine()!
        
        print("enter the employees commissionRate")
        
        commissionRate = readLine()!
        
    }
    
    
    func employee_hourlysalary()
        
    {
        
        return  weeklylySalary = Int(commissionRate) + Int(weeklySales) + Int(weeklySalary)
        
    }
    
    
    override func outputempDescription()
    {
        
        
        print (weeklydesc)
    }
    
    
    
    
    
}
