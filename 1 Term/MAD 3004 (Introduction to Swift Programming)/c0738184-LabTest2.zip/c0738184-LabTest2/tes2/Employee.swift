//
//  Employee.swift
//  tes2
//
// 
//

import Cocoa

class Employee: NSObject {

        
    
        var employeeId = ""
        
        var fname = ""
        
        var lname = ""
        
        var desc = ""
        
    
    
        func employee_id()
            
        {
            print("enter the employees id")
            
                employeeId = readLine()!
       }
            
    func empFname()
        
    {
        
    print("enter the employees firstname")
        
                fname = readLine()!
                
                
            }

    func empLname()
        
    {
            print("enter the employees lastname")
            
       
                lname = readLine()!
                
                
    }
      func empDescription()
      {
            print("Employee Description")
            
        
                desc = readLine()!
        
        }
    
        
        
func outputEmployeeID()
    
{

    
    print(employeeId)
}

func outputempFname()
    
{
    
    
     print(fname)
}

func outputempLname()
    
{
    
    
     print(lname)
}
func outputempDescription()
{
    
    
    print (desc)
}





}
