/*function currentbalance(){

var  x = document.myform.fromaccount.value;


    swtich(x){

          case "Checking":
          document.getElementById('current-balance')="100.00";
          break;


          case "Saving":
          document.getElementById('current-balance')="50.00";
          break;

          case Other:
          document.getElementById('current-balance')="20.00";
          break;
    }
}
*/

function validation(value)
{
var e = document.getElementById("fromaccount").innerHTML;


}
