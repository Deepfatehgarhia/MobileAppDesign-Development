
var coruser = new Array("User1","User2","User3");
var corpass = new Array("pass1","pass2","pass3");

function user(uservalue,User){

 var  users =  document.getElementById('username').value;

for(var i=0; i<coruser.length;i++){


      if(users == coruser[i])
      {
        var name = coruser[i];
        retun(document.getElementById('title').innerHTML = "Welcome " + name);

      }
    }

}


var loggeduser = null;

function clicked(){



      for(var i=0; i<coruser.length;i++)
      {
            if(document.getElementById("username").value == coruser[i])
            {
              if(document.getElementById('password').value == corpass[i])
              {


                  window.alert("You have logged in as "+ coruser[i]);
                    window.open("fundTransfer.html","_blank");

                    window.close("index.html","_blank");
                    setTimeout('self.close()',10);


                      loggeduser = coruser[i];

              }
              else{

                 window.alert("incorrect username or password!");
              }
            }
            else {

              window.alert("incorrect username or password!");
            }
      }
}







function logout(){

   setTimeout('self.close()',10);
  window.open("index.html","_blank");

}


function changepass(){


if(form.name.uservalue == "user1" && form.oldPassword.uservalue == "oldPassword")
{
  window.alert('user1');
}

else if(form.username.uservalue == "name1" && form.password.uservalue == "pass2")
{
  window.open('');
}

else if(form.username.value == "name2" && form.password.value == "pass2")
{
 window.open('');
}

}
