/*function currentbalance(){

var  x = document.myform.fromaccount.value;


    swtich(x){

          case "Checking":
          document.getElementById('current-balance')="100.00";
          break;


          case "Saving":
          document.getElementById('current-balance')="50.00";
          break;

          case Other:
          document.getElementById('current-balance')="20.00";
          break;
    }
}
*/

function validation(value)
{
var e = document.getElementById("fromaccount").innerHTML;

var strUser1 = e.options[e.selectedIndex].text;
swtich(strUser1){
      case "Checking":
      var x=100.00;
      document.getElementById("current").values=x;
      break;


      case "Saving":
      document.getElementById("current-balance").values="50.00";
      break;

      case "Other":
      document.getElementById("current-balance").vlaues="20.00";
      break;
}
}
