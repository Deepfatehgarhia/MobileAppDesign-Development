$('.collection-item').on('click', function(){

    var $badge = $('.badge', this);
    if($badge.length == 0) {
       $badge = $('<span class="badge brown-text">0</span>')
       .appendTo(this);
}
$badge.text(parseInt($badge.text()) + 1);
});

$('.modal-trigger').leanModal();

$('#confirm').on('click', function() {
  var text = '';
  $('.badge').parent().each(function() {
    var product = this.firstChild.textContent;
    var quantity = this.lastChild.textContent;
       text += product + ': ' + quantity + ', '
});
    $('#orderview').text(text);
});

$('.collection').on('click', '.badge', function(){
    $(this).remove();
    return false;
});

$('.action-clear').on('click', function() {
    $('#tablenum').val( '' );
    $('.badge').remove();
});
