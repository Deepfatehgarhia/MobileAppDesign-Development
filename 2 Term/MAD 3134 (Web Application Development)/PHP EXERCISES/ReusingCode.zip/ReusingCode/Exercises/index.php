<html>
<head>
<title>Northwind Home Page</title>
</head>
<body>
<h1 align="center">Log in</h1>
<form method="post" action="Login.php">
<table align="center">
	<tr>
		<td>Email:</td>
		<td><input type="text" name="Email" size="20"></td>
	</tr>
	<tr>
		<td>Password:</td>
		<td><input type="password" name="Password" size="10"></td>
	</tr>
	<tr>
		<td colspan="2" align="right">
			<input type="submit" value="Login">
		</td>
	</tr>
</table>
</form>
</body>
</html>
