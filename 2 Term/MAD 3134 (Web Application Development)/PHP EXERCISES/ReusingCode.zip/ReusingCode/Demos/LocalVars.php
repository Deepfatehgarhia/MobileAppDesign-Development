<html>
<head>
<title>Local Variables</title>
</head>

<body>
<?php
$a = 10;
$b = 5;

function incrNumBy()
{
	$a += $b;
}
incrNumBy(); //results in two warnings as $a and $b are
					//undefined in the function scope
echo $a; //outputs 10 to the browser
?>
</body>
</html>
