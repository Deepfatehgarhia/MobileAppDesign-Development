<html>
<head>
<title>Simple User-defined Function</title>
</head>

<body>
<?php
function addNums($param1, $param2, $param3)
{
	$sum = $param1 + $param2 + $param3;
	return $sum;
}

$Total = addNums(1,3,5);

echo $Total;
?>
</body>
</html>
