<html>
<head>
<title>Including Files</title>
</head>
<body>
This text is on the main page.
<hr/>
<?php
	require 'Includes/Required.php';
?>
<hr/>
<?php
	require 'Includes/Required.inc';
?>
</body>
</html>
