<div style="float:left">
	<a href="index.php">Home</a> |
	<a href="Forms.php">Forms</a> |
	<a href="Reports.php">Reports</a> |
	<a href="Login.php">Log in</a>
</div>
<div style="float:right; margin-bottom:20px;">
	<img src="Images/Northwind.gif" width="110" height="105"/>
</div>
<div style="clear:both"><hr/></div>
