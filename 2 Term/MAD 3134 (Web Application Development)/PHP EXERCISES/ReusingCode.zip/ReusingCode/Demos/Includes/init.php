<?php
	$ShowForm = true;

	$MgrEntries = array();
	$MgrEntries[1]='Nancy Davolio';
	$MgrEntries[2]='Andrew Fuller';
	$MgrEntries[3]='Janet Leverling';
	$MgrEntries[4]='Margaret Peacock';
	$MgrEntries[5]='Steven Buchanan';
	$MgrEntries[6]='Michael Suyama';
	$MgrEntries[7]='Robert King';
	$MgrEntries[8]='Laura Callahan';
	$MgrEntries[9]='Anne Dodsworth';

	$Errors = array();
	$DbEntries = array(	'FirstName'=>'',
						'LastName'=>'',
						'Email'=>'',
						'Title'=>'',
						'TitleOfCourtesy'=>'',
						'Address'=>'',
						'City'=>'',
						'Region'=>'',
						'PostalCode'=>'',
						'Country'=>'',
						'HomePhone'=>'',
						'Extension'=>'',
						'Notes'=>'',
						'ReportsTo'=>'',
						'Password'=>'',
						'Email'=>'',
						'BirthMonth'=>1,
						'BirthDay'=>1,
						'BirthYear'=>date('Y'),
						'HireMonth'=>1,
						'HireDay'=>1,
						'HireYear'=>date('Y'));	
	$BrowserEntries = array();
?>
