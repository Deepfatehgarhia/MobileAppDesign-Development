<br/>
<hr width="350" align="right">
<div align="right" id="copyright">
	&copy; Northwind Traders <?php echo date('Y') ?>. 
	All rights reserved.
</div>
