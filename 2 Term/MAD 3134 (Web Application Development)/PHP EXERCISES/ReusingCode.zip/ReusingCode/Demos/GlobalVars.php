<html>
<head>
<title>Global Variables</title>
</head>

<body>
<?php
$a = 10;
$b = 5;

function incrNumBy()
{
	global $a,$b;
	$a += $b;
}
incrNumBy(); 
echo $a; //outputs 15 to the browser
?>
</body>
</html>
