<html>
<head>
<title>By Reference</title>
</head>
<body>
<?php
	$a = 10;
	$b = 5;
	function incrNumBy(&$num,$incr)
	{
		$num += $incr;
	}
	
	incrNumBy($a,$b);
	echo $a; //outputs 15 to the browser
?>
</body>
</html>
