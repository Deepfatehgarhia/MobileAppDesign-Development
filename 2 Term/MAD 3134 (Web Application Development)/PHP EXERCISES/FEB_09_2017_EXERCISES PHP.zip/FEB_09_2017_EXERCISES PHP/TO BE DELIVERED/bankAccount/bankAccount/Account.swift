//
//  Account.swift
//  bankAccount
//
//  Created by Marcos Bittencourt on 08/02/17.
//  Copyright © 2017 Marcos Bittencourt. All rights reserved.
//

import Foundation

class Account {
    public let number :Int
    public private(set) var balance :Double
    public var status :String {
        get {
            if balance >= 0 {
                return "Positive"
            } else {
                return "Negative"
            }
        }
    }
    public private(set) var limit :Double
    public private(set) var transactions :[[String]]
    
    public var description :String {
        get {
            return "Account number: \(number)\nBalance: \(balance)\nLimit: \(limit)\nStatus: \(status)"
        }
    }
    
    init(accountNumber: Int, balance: Double, limit: Double){
        self.number = accountNumber
        self.balance = balance
        self.limit = limit
        self.transactions = [[]]
    }
    
    private func setBalance(balance: Double){
        if balance < 0 && abs(balance) > self.limit {
            self.balance = -1*self.limit
        } else {
            self.balance = balance
        }
    }
    
    public func setLimit(limit: Double){
        self.limit = limit
    }
    
    private func addTransaction(description: String, value: Double, type: String){
        let transaction = [description, String(value), type]
        self.transactions.append(transaction)
    }
    
    public func deposit(value: Double) -> Bool{
        addTransaction(description: "Deposit: \(value)", value: value, type: "d")
        self.balance += value
        return true
    }
    
    public func withdrawal(value: Double)->Bool{
        if(self.balance - value >= -self.limit){
            addTransaction(description: "Withdrawal: \(value)", value: value, type: "w")
            self.balance -= value
            return true
        } else {
            return false
        }
    }
}
