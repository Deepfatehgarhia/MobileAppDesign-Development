//
//  Bank.swift
//  bankAccount
//
//  Created by Marcos Bittencourt on 08/02/17.
//  Copyright © 2017 Marcos Bittencourt. All rights reserved.
//

import Foundation

class Bank {
    
    private var accounts: [Account]
    
    var description: String {
        var result = ""
        for i in accounts {
            result += i.description + "\n\n"
        }
        return result
    }
    
    init(){
        accounts = []
    }
    
    
    public func addAccount(number: Int, balance: Double, limit: Double) -> Bool{
        if findAccount(number: number) == -1 {
            accounts.append(Account(accountNumber: number, balance: balance, limit: limit))
            return true
        } else {
            return false
        }
    }
    
    public func removeAccount(number: Int) -> Bool{
        let position = findAccount(number: number)
        
        if position == -1 {
            return false
        } else {
            accounts.remove(at: position)
            return true
        }
    }
    
    public func withdrawal(number: Int, value: Double) -> Bool{
        let position = findAccount(number: number)
        
        if position == -1
        {
            return false
        } else {
            return accounts[position].withdrawal(value: value)
        }
    }
    
    public func deposit(number: Int, value: Double) -> Bool{
        let position = findAccount(number: number)
    
        if position == -1
        {
            return false
        } else {
            return accounts[position].deposit(value: value)
        }
    }
    
    public func transfer(from :Int, to: Int, value: Double) -> Bool{
        let position1 = findAccount(number: from)
        let position2 = findAccount(number: to)
        
        if position1 == -1 || position2 == -1{
            return false
        } else {
            let fromAccount = accounts[position1].withdrawal(value: value)
            var toAccount = false
            if fromAccount {
                    toAccount = accounts[position2].deposit(value: value)
            }
            return fromAccount && toAccount
        }
        
    }

    
    private func findAccount(number: Int) -> Int {
        var position = -1
        
        for i in 0..<accounts.count {
            if accounts[i].number == number {
                position = i
            }
        }
        return position
    }
    
}
