//
//  main.swift
//  bankAccount
//
//  Created by Marcos Bittencourt on 08/02/17.
//  Copyright © 2017 Marcos Bittencourt. All rights reserved.
//

import Foundation

var bank = Bank();

print("Account 1 created: \(bank.addAccount(number: 1, balance: 1000, limit: 1500))")
print("Account 2 created: \(bank.addAccount(number: 2, balance: 800, limit: 2000))")
print("Account 3 created: \(bank.addAccount(number: 2, balance: 1500, limit: 0))\n\n")

print(bank.description)

print("Account 1 deposit: \(bank.deposit(number: 1, value: 1000))")
print("Account 2 withdrawal: \(bank.withdrawal(number: 2, value: 50))\n\n")

print(bank.description)

print("Account 2 withdrawal: \(bank.withdrawal(number: 2, value: 5000))\n\n")

print(bank.description)

print("Account Transfer 100: \(bank.transfer(from: 1, to: 2, value: 100))")

print(bank.description)

print("Account Transfer  10000: \(bank.transfer(from: 1, to: 2, value: 10000))")

print(bank.description)




