<?php
	//For each entry coming through the form,
	//  create a simple global variable to hold...
	//	- either an error if the entry is not filled or filled incorrectly
	//	- or the value entered.
	//The first one is done for you.

	if ($_POST['FirstName'] == '')
	{
		$FirstName = '<span style="color:red;">First name omitted.</span>';
	}
	else
	{
		$FirstName = $_POST['FirstName'];
	}
?>
<html>
<head>
<title>Process Employee</title>
</head>
<body>
	<h1>Process Employee</h1>
	<ul>
	<?php
	//Output the variables as list items.
	//Part of the first one is done for you.
		echo "<li><b>Name:</b> $FirstName</li>";
	?>
	</ul>
</body>
</html>
